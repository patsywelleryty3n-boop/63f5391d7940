// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cmake config export\n", stdout);
  return lionss_run_workload("cmake-config-export");
}
