// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("portage ebuild"); }
int main(){
  announce();
  return lionss_run_workload("portage-ebuild");
}
