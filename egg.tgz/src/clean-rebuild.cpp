// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("clean rebuild"); }
int main(){
  announce();
  return lionss_run_workload("clean-rebuild");
}
