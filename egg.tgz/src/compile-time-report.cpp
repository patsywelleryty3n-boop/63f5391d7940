// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("compile time report\n", stdout);
  return lionss_run_workload("compile-time-report");
}
