// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("pitest run\n", stdout);
  return lionss_run_workload("pitest-run");
}
